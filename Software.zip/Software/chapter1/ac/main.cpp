//
//  main.cpp
//  ac
//
//  Created by Yong on 2024/3/24.
//

#include <iostream>
typedef unsigned char byte;

////////////////////////////////////////////////////////////////////////////////////////////////
const int WIDTH = 32;
const unsigned HRNG = (1U<<(WIDTH-1));    // half of the range
const unsigned QRNG = (1U<<(WIDTH-2));    // quarter of the range
const unsigned MASK = HRNG|(HRNG-1);

////////////////////////////////////////////////////////////////////////////////////////////////
void encode_symbol(byte *str, unsigned &low, unsigned &high, int &ptr, int &nuf, byte x, double p){
    if(x) low += unsigned((high-low)*(1-p)+(1.5-p));        // update the lower bound of "1"
    else  high = low + unsigned((high-low)*(1-p)+(0.5-p));  // update the upper bound of "0"
    while(!((high^low)&HRNG)){
        str[ptr++] = (low>=HRNG);
        while(nuf){
            str[ptr++] = (low<HRNG);
            nuf--;
        }
        low <<= 1; high <<= 1; high |= 1;
    }
    while((high&QRNG)<(low&QRNG)){
        nuf++;
        low  -= QRNG; low  <<= 1;
        high -= QRNG; high <<= 1; high |= 1;
    }
}
int compress(byte *str, const byte *x, int n, double p){
    int ptr=0, nuf=0;
    unsigned low=0, high=MASK;
    memset(str, 0, n*sizeof(byte));
    for(int i=0; i<n; i++){
        encode_symbol(str, low, high, ptr, nuf, x[i], p);
    }
    str[ptr] = 1;
    return ptr;
}

////////////////////////////////////////////////////////////////////////////////////////////////
byte get_symbol(unsigned low, unsigned high, unsigned code, double p){
    return (code-low)>unsigned((high-low)*(1-p)+(0.5-p));
}
void remove_symbol(const byte *str, unsigned &low, unsigned &high, unsigned &code, int &ptr, byte x, double p){
    if(x) low += unsigned((high-low)*(1-p)+(1.5-p));        // update the lower bound of "1"
    else  high = low + unsigned((high-low)*(1-p)+(0.5-p));  // update the upper bound of "0"
    while(!((high^low)&HRNG)){
        low  <<= 1;
        high <<= 1; high |= 1;
        code <<= 1; code |= str[ptr++];
    }
    while((high&QRNG)<(low&QRNG)){
        low  -= QRNG; low  <<= 1;
        high -= QRNG; high <<= 1; high |= 1;
        code -= QRNG; code <<= 1; code |= str[ptr++];
    }
}
void expand(byte *xr, const byte *str, int n, double p){
    int ptr=0;
    unsigned low=0, high=MASK, code=0;
    for(int i=0; i<WIDTH; i++){
        code <<= 1;
        code |= str[ptr++];
    }
    for(int i=0; i<n; i++){
        xr[i] = get_symbol(low, high, code, p);
        remove_symbol(str, low, high, code, ptr, xr[i], p);
    }
}
////////////////////////////////////////////////////////////////////////////////////////////////
int main(int argc, const char * argv[]){
    double p=atof(argv[1]); // bias probability
    int n=atoi(argv[2]);    // x^n: source block
    std::cout<<"p = "<<p<<", "<<"n = "<<n<<std::endl;
    byte *x=new byte[3*n], *str=x+n, *xr=str+n;
    for(int i=0; i<n; i++){
        x[i] = (rand()<RAND_MAX*p);
    }
    int m = compress(str, x, n, p);
    expand(xr, str, n, p);
    if(memcmp(x,xr,n)!=0){
        std::cout<<"ERROR!"<<std::endl;
    }
    std::cout<<"H(X) = H_b(p) = "<<-(p*log2(p)+(1-p)*log2(1-p))<<std::endl;
    std::cout<<"R = "<<m<<"/"<<n<<" = "<<m/(double)n<<std::endl;
    return 0;
}
