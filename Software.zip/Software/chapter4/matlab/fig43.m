%% this file generates Figure 4.3 in the monograph.

addpath data
clc; clear;

load data_20_10;

%% plot Fig. 4.3(a) for f_{W|n}(w) = f_{W|j^n}(w)
figure(1);
theo = zeros(1,2^(ceil(n*r)+1)+1);
w = -1*2^ceil(n*r) : round((2*sqrt(2)-3)*2^ceil(n*r));
theo(w+2^ceil(n*r)+1) = (1+w/2^ceil(n*r))/(12*sqrt(2)-16);
w = round((2*sqrt(2)-3)*2^ceil(n*r)) : round((3-2*sqrt(2))*2^ceil(n*r));
theo(w+2^ceil(n*r)+1) = 1/(4-2*sqrt(2));
w = round((3-2*sqrt(2))*2^ceil(n*r)) : 1*2^ceil(n*r);
theo(w+2^ceil(n*r)+1) = (1-w/2^ceil(n*r))/(12*sqrt(2)-16);
w = (-2^ceil(n*r):2^ceil(n*r))/2^ceil(n*r);
plot(w, theo); hold on;
plot(w, pmf(n,:));
grid on; axis tight;
xlabel({'$w$'}, 'interpreter', 'latex');
ylabel({'$f_{W|n}(w)$ and $f_{W|j^n}(w)$'}, 'interpreter', 'latex');
legend({'TH','EXP'}, 'interpreter', 'latex');
title({'$n=20$, $r=1/2$'}, 'interpreter', 'latex'); % to change figure title here
set(gca,'FontSize',16);

%% plot Fig. 4.3(b) for f_{W|j^{n-1}}(w) for j^{n-1} = (1,...,(n-1)), i.e., k=1
figure(2);
theo = zeros(1,2^(ceil(n*r)+1)+1);
w = round(-2^ceil(n*r)/sqrt(2)) : round((2-3/sqrt(2))*2^(ceil(n*r)));
theo(w+2^ceil(n*r)+1) = (1/2+w/sqrt(2)/2^ceil(n*r))/(6-4*sqrt(2));
w = round((2-3/sqrt(2))*2^(ceil(n*r))) : round((3/sqrt(2)-2)*2^(ceil(n*r)));
theo(w+2^ceil(n*r)+1) = 1/(2*sqrt(2)-2);
w = round((3/sqrt(2)-2)*2^(ceil(n*r))) : round(2^ceil(n*r)/sqrt(2));
theo(w+2^ceil(n*r)+1) = (1/2-w/sqrt(2)/2^ceil(n*r))/(6-4*sqrt(2));
w = (-2^ceil(n*r):2^ceil(n*r))/2^ceil(n*r);
plot(w, theo);hold on;
plot(w, pmfspecial(n,:)); 
grid on; axis tight;
xlabel({'$w$'}, 'interpreter', 'latex');
ylabel({'$f_{W|j^{n-1}}(w)$'}, 'interpreter', 'latex');
legend({'TH','EXP'}, 'interpreter', 'latex');
title({'$n=20$, $r=1/2$, $k=1$'}, 'interpreter', 'latex'); % to change figure title here
set(gca,'FontSize',16);

%% plot Fig. 4(c) for f_{W|j^{n-1}}(w) for j^{n-1} = (1,...,(n-2),n), i.e., k=2
figure(3);
theo = zeros(1,2^(ceil(n*r)+1)+1);
w = round(2^ceil(n*r)*(sqrt(2)-3)/2) : round(2^ceil(n*r)*(3*sqrt(2)-5)/2);
theo(w+2^ceil(n*r)+1) = ((3-sqrt(2))/2+w/2^ceil(n*r))/(6*sqrt(2)-8);
w = round(2^ceil(n*r)*(3*sqrt(2)-5)/2) : round(2^ceil(n*r)*(5-3*sqrt(2))/2);
theo(w+2^ceil(n*r)+1) = 1/(4-2*sqrt(2));
w = round(2^ceil(n*r)*(5-3*sqrt(2))/2) : round(2^ceil(n*r)*(3-sqrt(2))/2);
theo(w+2^ceil(n*r)+1) = ((3-sqrt(2))/2-w/2^ceil(n*r))/(6*sqrt(2)-8);
w = (-2^ceil(n*r):2^ceil(n*r))/2^ceil(n*r);
plot(w, theo);hold on;
plot(w, pmfspecial(n-1,:)); 
grid on; axis tight;
xlabel({'$w$'}, 'interpreter', 'latex');
ylabel({'$f_{W|j^{n-1}}(w)$'}, 'interpreter', 'latex');
legend({'TH','EXP'}, 'interpreter', 'latex');
title({'$n=20$, $r=1/2$, $k=2$'}, 'interpreter', 'latex'); % to change figure title here
set(gca,'FontSize',16);

%% plot Fig. 4(d) for f_{W|j^{n-1}}(w) for other j^{n-1} or other k
figure(4);
theo = zeros(1,2^(ceil(n*r)+1)+1);
w = -1*2^ceil(n*r) : round((2*sqrt(2)-3)*2^ceil(n*r));
theo(w+2^ceil(n*r)+1) = (1+w/2^ceil(n*r))/(12*sqrt(2)-16);
w = round((2*sqrt(2)-3)*2^ceil(n*r)) : round((3-2*sqrt(2))*2^ceil(n*r));
theo(w+2^ceil(n*r)+1) = 1/(4-2*sqrt(2));
w = round((3-2*sqrt(2))*2^ceil(n*r)) : 1*2^ceil(n*r);
theo(w+2^ceil(n*r)+1) = (1-w/2^ceil(n*r))/(12*sqrt(2)-16);
w = (-2^ceil(n*r):2^ceil(n*r))/2^ceil(n*r);
plot(w, theo); hold on;
plot(w, pmfspecial(n-3,:));
plot(w, pmfspecial(n-7,:));
plot(w, pmfspecial(n-11,:));
plot(w, pmfspecial(n-15,:));
grid on; axis tight;
xlabel({'$w$'}, 'interpreter', 'latex');
ylabel({'$f_{W|j^{n-1}}(w)$'}, 'interpreter', 'latex');
legend({'TH','$k=4$','$k=8$','$k=12$','$k=16$'}, 'interpreter', 'latex');
title({'$n=20$, $r=1/2$'}, 'interpreter', 'latex'); % to change figure title here
set(gca,'FontSize',16);

