%% this file generates Figure 4.2 in the monograph.

%% to generate Fig. 4.2(a)
figure(1);
r = zeros(8);
for i=1:8
    for j=1:8
        r(i,j) = log2(fsolve(@(x) x.^(i+j)-x.^i-1, 1.5));
    end
end
semilogy(r(1,:), '-o'); hold on;
semilogy(r(2,:), '-o');
semilogy(r(3,:), '-o');
semilogy(r(4,:), '-o');
semilogy(r(5,:), '-o');
grid on;
axis tight;
xlabel({'$j$'}, 'interpreter', 'latex', 'fontsize', 16);
ylabel({'$r$'}, 'interpreter', 'latex', 'fontsize', 16);
legend({'$i=1$', '$i=2$', '$i=3$', '$i=4$', '$i=5$'}, 'interpreter', 'latex', 'fontsize', 16);

%% to generate Fig. 4.2(b)
figure(2);
n = 14:2:24;
hds3_7549 = [15.824219, 16.729599, 17.736191, 18.818878, 19.852066, 20.769623];
plot(n,hds3_7549, '-o'); hold on;
x = fsolve(@(x) x^3-x-1, 1.5);
plot(n,(79-12*x^2-17*x)/4 + n/2, '-*');

n=12:4:28;
hds3_618 = [2.756900, 3.741600, 4.741400, 5.747900, 6.751700];
plot(n,hds3_618, '-o');
plot(n,(n-1)/4, '-*');

grid on;
axis tight;
xlabel({'$n$'}, 'interpreter', 'latex', 'fontsize', 16);
ylabel({'$\psi(3;n)$'}, 'interpreter', 'latex', 'fontsize', 16);
legend({'$x^3-x=1$, experiment', '$x^3-x=1$, theory', '$x^2-x=1$, experiment', '$x^2-x=1$, theory'}, 'interpreter', 'latex', 'fontsize', 16);
