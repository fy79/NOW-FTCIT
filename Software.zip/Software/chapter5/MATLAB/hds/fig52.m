%% this file generates Figure 5.2 in the monograph.

addpath functions
clc; clear;
global hds;

%% generate Fig. 5.2(a)
figure(1);
n = 12; R = 0.5;

t = 0;
hds = zeros(1,n);
w = zeros(1,n);
tic; fhds(n,R,1,w,t); toc;
hds = hds./2.^(0:(n-1));
plot(hds, '-+'); hold on;

t = 2;
hds = zeros(1,n);
w = zeros(1,n);
tic; fhds(n,R,1,w,t); toc;
hds = hds./2.^(0:(n-1));
plot(hds, '-xr');

t = 4;
hds = zeros(1,n);
w = zeros(1,n);
tic; fhds(n,R,1,w,t); toc;
hds = hds./2.^(0:(n-1));
plot(hds, '-*g');

t = 6;
hds = zeros(1,n);
w = zeros(1,n);
tic; fhds(n,R,1,w,t); toc;
hds = hds./2.^(0:(n-1));
plot(hds, '-oc');

grid on; axis tight;
set(gca, 'FontSize', 16);
xlabel({'$d$'}, 'interpreter', 'latex');
ylabel({'$\psi(d;n)$'}, 'interpreter', 'latex');
legend({'$t=0$','$t=2$','$t=4$','$t=6$'}, 'interpreter', 'latex');
title({'$n=12$, $R=0.5$'}, 'interpreter', 'latex'); % to change figure title here


%% generate Fig. 5.2(b)
figure(2);
n = 12; R = 0.75;

t = 0;
hds = zeros(1,n);
w = zeros(1,n);
tic; fhds(n,R,1,w,t); toc;
hds = hds./2.^(0:(n-1));
plot(hds, '-+'); hold on;

t = 3;
hds = zeros(1,n);
w = zeros(1,n);
tic; fhds(n,R,1,w,t); toc;
hds = hds./2.^(0:(n-1));
plot(hds, '-xr');

t = 6;
hds = zeros(1,n);
w = zeros(1,n);
tic; fhds(n,R,1,w,t); toc;
hds = hds./2.^(0:(n-1));
plot(hds, '-*g');

t = 9;
hds = zeros(1,n);
w = zeros(1,n);
tic; fhds(n,R,1,w,t); toc;
hds = hds./2.^(0:(n-1));
plot(hds, '-oc');

grid on; axis tight;
set(gca, 'FontSize', 16);
xlabel({'$d$'}, 'interpreter', 'latex');
ylabel({'$\psi(d;n)$'}, 'interpreter', 'latex');
legend({'$t=0$','$t=3$','$t=6$','$t=9$'}, 'interpreter', 'latex');
title({'$n=12$, $R=0.75$'}, 'interpreter', 'latex'); % to change figure title here







