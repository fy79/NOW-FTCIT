function fhds(n,R,i,w,t)
% n: code length
% R: code rate
% i: symbol index, 1<=i<=n
% w: length-n ternary sequence {-1,0,+1}
% t: tail length
r = (n*R-t)/(n-t);
global hds;
if i<=n
    w(i) = 0;
    fhds(n,R,i+1,w,t);
    w(i) = -1;
    fhds(n,R,i+1,w,t);
    if i>1 && any(w(1:(i-1)))
        w(i) = +1;    
        fhds(n,R,i+1,w,t);
    end
else % i>n
    d = sum(abs(w));
    if d>0 
        tau = 2^t*(1-2^(-r))*sum(w(1:(n-t)).*2.^((1:(n-t))*r)) + sum(w((n-t+1):n).*2.^(0:(t-1)));
        if abs(tau)<1
            if d<n
                hds(d) = hds(d) + (1-abs(tau));
            else
               hds(d) = hds(d) + 1;
            end
        end
    end  
end 
end