function gethdsx(R,d,level,x)
global J;
global HDS_INC;
if level>1
    for temp=(level-1):(J(level)-1)
        J(level-1) = temp;
        gethdsx(R,d,level-1,x);
    end
else
    temp = sum((-1).^bitget(x,1:d) .* 2.^(J*R));
    temp = max(0, 1-(1-2^(-R))*abs(temp));
    HDS_INC(x+1) = HDS_INC(x+1) + temp;
end
end