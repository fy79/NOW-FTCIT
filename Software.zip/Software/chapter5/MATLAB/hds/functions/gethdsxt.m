function gethdsxt(R,d,level,x,n,t)
global J;
global HDS_INC;
r = (n*R-t)/(n-t);
if level>1
    for temp=(level-1):(J(level)-1)
        J(level-1) = temp;
        gethdsxt(R,d,level-1,x,n,t);
    end
else
    Jbody = J(J>t);
    Jtail = J(J<=t);
    
    if ~isempty(Jbody)
        temp = 2^t * (1-2^(-r)) * sum((-1).^bitget(x,1:length(Jbody)) .* 2.^((Jbody-t)*r));
    else
        temp = 0;
    end
    
    if ~isempty(Jtail)
        temp = temp + (1-2^(-1))*sum((-1).^bitget(x,(length(Jbody)+1):d) .* 2.^Jtail);    
    end
    
    if length(J)==n
        HDS_INC(x+1) = HDS_INC(x+1) + (abs(temp)<1);
    else
        HDS_INC(x+1) = HDS_INC(x+1) + max(0, 1-abs(temp));
    end
end
end