%% this file generates Figure 5.1 in the monograph.

clc; clear;
n = 64; R = 0.5;

%% generate Fig. 5.1(a)
figure(1);
t = 0:(n*R-1);
r = (n*R-t)./(n-t);
semilogy(t, 2.^t .* (2.^r-1), '*'); hold on;
semilogy(t, 2.^t .* (2.^r-1).^2, 'ro'); 
axis tight; grid on;
set(gca, 'FontSize', 16);
xlabel({'$t$'}, 'interpreter', 'latex');
% ylabel({''}, 'interpreter', 'latex');
title({'$n=64$, $R=0.5$'}, 'interpreter', 'latex');
legend({'$2^t(2^r-1)$', '$2^t(2^r-1)^2$'}, 'interpreter', 'latex' ,'location', 'best');

%% generate Fig. 5.1(b)
figure(2)
for t=0:(n*R-1)
    r = (n*R-t)/(n-t);
    A = (2^r-1) .* 2.^(t+(0:(n-t-1))*r);   
    deltaA = min(A - 2.^floor(log2(A)), 2.^ceil(log2(A)) - A);
    semilogy(t*ones(size(A)), deltaA, '.'); hold on;
end
axis tight; grid on;
set(gca, 'FontSize', 16);
xlabel({'$t$'}, 'interpreter', 'latex');
ylabel({'$\Delta_i$'}, 'interpreter', 'latex');
title({'$n=64$, $R=0.5$'}, 'interpreter', 'latex');
% legend({''}, 'interpreter', 'latex' ,'location', 'best');
