%% this file generates Figure 5.3 in the monograph.

addpath functions
clc; clear;
global J;           % indices of non-zero z symbols
global HDS_INC;     % increment of HDS after each loop

n = 64; R = 0.5;    % to change code length and rate here
hds = zeros(n*R,n);
for t=0:(n*R-1)
    for d=1:3
        J = 1:d;
        HDS_INC = zeros(1,2^(d-1));
        if d==n
            for x=0:(2^(d-1)-1)
                gethdsxt_special(n,R,t,x);
                hds(t+1,d) = hds(t+1,d) + HDS_INC(x+1);
            end
        else
            while(1)
                HDS_INC(:) = 0;
                for x=0:(2^(d-1)-1)
                    gethdsxt(R,d,d,x,n,t);
                    hds(t+1,d) = hds(t+1,d) + HDS_INC(x+1);
                end
                if J(d)==n
                    break;
                else
                    J(d) = J(d)+1;            
                end
            end
        end
        hds(t+1,d) = hds(t+1,d)*2^(1-d);
    end
end

plot(0:(n*R-1), hds(:,1), '-+'); hold on;
plot(0:(n*R-1), hds(:,2), '-xr'); 
plot(0:(n*R-1), hds(:,3), '-*g'); 
grid on; axis tight;
set(gca, 'FontSize', 16);
xlabel({'$t$'}, 'interpreter', 'latex');
ylabel({'$\psi(d;n)$'}, 'interpreter', 'latex');
legend({'$d=1$','$d=2$','$d=3$'}, 'interpreter', 'latex');
title({'$n=64$, $R=0.5$'}, 'interpreter', 'latex'); % to change figure title here





