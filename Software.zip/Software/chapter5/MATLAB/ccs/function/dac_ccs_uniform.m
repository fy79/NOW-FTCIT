function [ccs,pmf]= dac_ccs_uniform(n,R,T)
%% [ccs,pmf] = dac_ccs_uniform(n,R,T)
fi0 = zeros(1,T);
fi1 = zeros(1,T);   
ccs = ones(n+1,T);  % codebook cardinality spectrum
pmf = zeros(n,T,2); % symbol pmf according to ccs
H = round(T*2^(-R));
t = round((0:(H-1))*2^R) + 1;
for i=n:-1:1    
    fi0(1:H) = ccs(i+1,t); 
    fi0 = T*fi0/sum(fi0); 
    fi1(T:-1:1) = fi0;
%     fi1((T-H)+(1:H)) = fi0(1:H);
    ccs(i,:) = (fi0+fi1)/2;    
    pmf(i,:,1) = fi1./(2*ccs(i,:)); 
    pmf(i,:,2) = 1-pmf(i,:,1);
end











 
%% I had tried the following more complex methods, but found no improvement
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% ccs = ones(n+1,T-1);
% fi0 = zeros(1,T-1);
% fi1 = zeros(1,T-1); 
% H = round(T*2^(-R));
% t = round((1:(H-1))*2^R);
% for i=n:-1:1
%     fi0(1:(H-1)) = ccs(i+1,t);
%     fi0(H:(T-1)) = 0;
%     fi1(1:(T-H)) = 0;
%     fi1((T-H)+(1:(H-1))) = fi0(1:(H-1));    
%     fi0 = (T-1)*fi0/sum(fi0);
%     fi1 = (T-1)*fi1/sum(fi1);    
%     ccs(i,:) = (fi0+fi1)/2;
%     plot(ccs(i,:));
%     disp(mse(ccs(i,:)-ccs(i+1,:)));
% end  

%% 
% ccs = ones(n+1,T-1);
% fi0 = zeros(1,T-1);
% fi1 = zeros(1,T-1); 
% t = ((1:(H-1))-H/2)*2^R + T/2;
% t = round(t);
% for i=n:-1:1
%     fi0(1:(H-1)) = ccs(i+1,round(t));
%     fi0(H:(T-1)) = 0;
%     fi1(1:(T-H)) = 0;
%     fi1((T-H+1):(T-1)) = fi0(1:(H-1));    
%     fi0 = T*fi0/sum(fi0);
%     fi1 = T*fi1/sum(fi1);    
%     ccs(i,:) = (fi0+fi1)/2;
%     plot(ccs(i,:));
%     disp(mse(ccs(i,:)-ccs(i+1,:)));
% end  

%%
% ccs = ones(n+1,T);
% fi0 = zeros(1,T);
% fi1 = zeros(1,T);
% for i=n:-1:1
%     t = (0:(H-1))*2^R + 1;
%     fi0(1:H) = ccs(i+1,round(t));
%     fi0((H+1):T) = 0;
%           
%     fi1(1:(T-H)) = 0;    
%     t = T-(T-((T-H):(T-1)))*2^R+1;    
%     fi1((T-H)+(1:H)) = ccs(i+1,round(t));
%     
%     fi0 = T*fi0/sum(fi0);
%     fi1 = T*fi1/sum(fi1);
%     
%     ccs(i,:) = (fi0+fi1)/2;
%     disp(mse(ccs(i,:)-ccs(i+1,:)));
% end

%%
% ccs = ones(n+1,T);
% fi0 = zeros(1,T);
% fi1 = zeros(1,T);
% for i=n:-1:1   % from the final ccs to the initial ccs
%     t = (0:(H-1))*2^R + 1;
%     fi0(1:H) = (t-floor(t)).*ccs(i+1,ceil(t)) + (ceil(t)-t).*ccs(i+1,floor(t));
%     fi0((H+1):T) = 0;
%     fi1(1:(T-H)) = 0;
%     fi1((T-H+1):T) = fi0(1:H);
%     fi0 = T*fi0/sum(fi0);
%     fi1 = T*fi1/sum(fi1);    
%     ccs(i,:) = (fi0+fi1)/2;
%     disp(mse(ccs(i,:)-ccs(i+1,:)));
% end
 
% for i=n:-1:1   
%     plot(ccs(i,:));  
% end 
% axis tight; 
% grid on;         
