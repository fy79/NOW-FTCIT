%% this file generates Figure 5.4 in the monograph.
addpath function
clc; clear;

%% generate Fig. 5.4(a)
figure(1);
N = 2^12;       % number of cells
n = 64;         % code length
R = 0.5;        % average code rate
t = [0, (n*R)-3, (n*R)-2, (n*R)-1, (n*R)];
r = (n*R-t)./(n-t);   % code rate for body symbols
loss = zeros(size(t));
allccs = zeros(length(t), N);
for k=1:length(t)            % tail length
    [ccs, pmf] = dac_ccs_uniform(n-t(k), r(k), N);   % ccs is a matrix of size (n-t+1)xN
    loss(k) = sum(ccs(1,:).*log2(ccs(1,:)))/N;
    allccs(k,:) = ccs(1,:);
end
plot(0:(1/N):(1-1/N), allccs(1,:)); hold on;
plot(0:(1/N):(1-1/N), allccs(2,:), 'r'); 
plot(0:(1/N):(1-1/N), allccs(3,:), 'g'); 
plot(0:(1/N):(1-1/N), allccs(4,:), 'm'); 
plot(0:(1/N):(1-1/N), allccs(5,:), 'c'); 

axis tight; grid on;
set(gca, 'FontSize', 16);
xlabel({'$u$'},'interpreter','latex');
ylabel({'$f_{0,n}(u)$'},'interpreter','latex');
title({'$n=64$, $R=0.5$, $N=2^{12}$'},'interpreter','latex');
legend({'$t=0$', '$t=nR-3$', '$t=nR-2$', '$t=nR-1$', '$t=nR$'}, 'interpreter', 'latex');

%% generate Fig. 5.4(b)
figure(2);
N = 2^12;
n = 64;
R = 0.5;        % average code rate
t = 0:(n*R);
r = (n*R-t)./(n-t);   % code rate for body symbols
loss = zeros(size(t));
cbsize = zeros(size(t));
for k=1:length(t)            % tail length
    [ccs, pmf] = dac_ccs_uniform(n-t(k), r(k), N);   % ccs is a matrix of size (n-t+1)xN
    loss(k) = sum(ccs(1,:).*log2(ccs(1,:)))/N;    
    cbsize(k) = sum(ccs(1,:).^2)/N;
end
plot(t, cbsize-1, '-o'); hold on;
plot(t, loss, '-*r'); 
axis tight; grid on; 
set(gca, 'FontSize', 16);
xlabel({'$t$'},'interpreter','latex');
title({'$n=64$, $R=0.5$, $N=2^{12}$'},'interpreter','latex');
legend({'$\eta-1$', '$-h(U_{0,n})$'}, 'interpreter', 'latex', 'location', 'best');





