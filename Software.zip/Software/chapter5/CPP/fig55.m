%% this file generates Figure 5.5 in the monograph.

%% generate Fig. 5.5(a)
figure(1);
t = [0,8,16:23,32];
f10_5 = [0.196470, 0.031250, 0.011038, 0.009755, 0.008529, 0.007929, 0.008266, 0.010330, 0.009614, 0.009314, 0.019155];
f8_5  = [0.193939, 0.037356, 0.025551, 0.026152, 0.023708, 0.023488, 0.025172, 0.027649, 0.026840, 0.028845, 0.046835];
semilogy(t,f10_5,'-*'); hold on;
semilogy(t,f8_5,'-o');
grid on; axis tight;
set(gca, 'FontSize', 16);
title({'$n=2^8$, $R=0.5$, $\epsilon=0.05$'}, 'interpreter', 'latex');
xlabel({'$t$'}, 'interpreter', 'latex');
ylabel({'Frame-Error-Rate'}, 'interpreter', 'latex');
legend({'$M=2^{10}$','$M=2^8$'}, 'interpreter', 'latex');

%% generate Fig. 5.5(b)
figure(2);
t = [0,8:17];
f10_7 = [0.357542, 0.129752, 0.114593, 0.115995, 0.094222, 0.093397, 0.091038, 0.088704, 0.089573, 0.093945, 0.093159];% 0.091038, 0.093397, 0.093773, 0.102770, 0.096896, 0.096896, 0.138678];
f8_7  = [0.358042, 0.163788, 0.150943, 0.154124, 0.135164, 0.138678, 0.132574, 0.144960, 0.146119, 0.150943, 0.165055];% 0.157152, 0.155907];
semilogy(t,f10_7,'-*'); hold on;
semilogy(t,f8_7,'-o');
grid on; axis tight;
set(gca, 'FontSize', 16);
title({'$n=2^8$, $R=0.5$, $\epsilon=0.07$'}, 'interpreter', 'latex');
xlabel({'$t$'}, 'interpreter', 'latex');
ylabel({'Frame-Error-Rate'}, 'interpreter', 'latex');
legend({'$M=2^{10}$','$M=2^8$'}, 'interpreter', 'latex');
