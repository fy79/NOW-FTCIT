#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <memory.h>
#include <math.h>
#include <float.h>
#include <iostream>
using namespace std;
typedef unsigned char byte;

////////////////////////////////////////////////////////////////////////////////////////////////
static double steps[3];
void setsteps(double p, double r){
    // [0, steps[2], steps[0], steps[1], 1)
    steps[0] = 1-p;
    steps[1] = powf(1-p,r); // upper bound of "0": (1-p)^r => [0, steps[1])
    steps[2] = 1-powf(p,r); // lower bound of "1": (1-p^r) => [steps[2], 1)
}
////////////////////////////////////////////////////////////////////////////////////////////////
struct NODE{
    unsigned low, high, code;
    int ptr, metric;
    NODE *parent, *kids[2];
};
static NODE **paths=NULL;
static NODE *nodes=NULL;
static byte *str=NULL;/* This is the i/o buffer    */
void new_codec(int n, int M){
    str = new byte[n];
    nodes = new NODE[(M<<1)*n+1];
    paths = new NODE*[(M<<1)+1];
}
void free_codec(void){
    delete[] str;
    delete[] nodes;
    delete[] paths;
}
////////////////////////////////////////////////////////////////////////////////////////////////
const int WIDTH = 32;
const unsigned HRNG = (1U<<(WIDTH-1));    // half of the range
const unsigned QRNG = (1U<<(WIDTH-2));    // quarter of the range
const unsigned MASK = HRNG|(HRNG-1);
////////////////////////////////////////////////////////////////////////////////////////////////
void encode_symbol(unsigned &low, unsigned &high, int &ptr, int &underflow, byte x, bool b=true){
    int a = b+(b&x);
    unsigned length = unsigned((high-low)*steps[a]+steps[a]+0.5);// the only float-point operation
    if(x) low += length;            // update the lower bound of "1"
    else  high = low + length - 1;  // update the upper bound of "0"
    while(!((high^low)&HRNG)){
        str[ptr++] = (low>=HRNG);
        while(underflow){
            str[ptr++] = (low<HRNG);
            underflow--;
        }
        low <<= 1; high <<= 1; high |= 1;
    }
    while((high&QRNG)<(low&QRNG)){
        low  -= QRNG; low  <<= 1;
        high -= QRNG; high <<= 1; high |= 1;
        underflow++;
    }
}
int compress(const byte *x, int n, int t){
    int ptr=0, underflow=0;
    unsigned low=0, high=MASK;
    memset(str, 0, n*sizeof(byte));
    for(int i=0; i<n; i++){
        encode_symbol(low, high, ptr, underflow, x[i], i<(n-t));
    }
    str[ptr] = 1;
    return ptr;
}
////////////////////////////////////////////////////////////////////////////////////////////////
NODE *create_root(int &nNodes){
    NODE *root = nodes+(nNodes++);
    root->low = 0; root->high = MASK; root->code = 0; root->ptr = 0;
    for(int i=0; i<WIDTH; i++){
        root->code <<= 1;
        root->code |= str[root->ptr++];
    }
    root->metric = 0;
    root->parent = NULL; root->kids[0] = NULL; root->kids[1] = NULL;
    return root;
}
void remove_symbol(unsigned &low, unsigned &high, unsigned &code, int &ptr, byte x, bool b=true){
    int a = b+(b&x);
    unsigned length = unsigned((high-low)*steps[a]+steps[a]+0.5);// the only float-point operation
    if(x) low += length;            // update the lower bound of "1"
    else  high = low + length - 1;  // update the upper bound of "0"
    while(!((high^low)&HRNG)){
        low  <<= 1;
        high <<= 1; high |= 1;
        code <<= 1; code |= str[ptr++];
    }
    while((high&QRNG)<(low&QRNG)){
        low  -= QRNG; low  <<= 1;
        high -= QRNG; high <<= 1; high |= 1;
        code -= QRNG; code <<= 1; code |= str[ptr++];
    }
}
NODE *create_kid(NODE *parent, int &nNodes, byte x, byte y, bool b){
    NODE *kid = nodes+(nNodes++);
    memcpy(kid, parent, 3*sizeof(unsigned)+sizeof(int));// (low, high, code, ptr)
    remove_symbol(kid->low, kid->high, kid->code, kid->ptr, x, b);
    kid->metric = parent->metric - (x^y); // update metric
    kid->parent = parent; kid->kids[0] = NULL; kid->kids[1] = NULL;
    parent->kids[x] = kid;
    return kid;
}
byte get_symbol(unsigned low, unsigned high, unsigned code, bool b=true){
    unsigned bound0 = unsigned((high-low)*steps[b<<1]+steps[b<<1]+0.5);
    unsigned bound1 = unsigned((high-low)*steps[b]+steps[b]+0.5);
    if((code-low)<bound0)       return 0; // < 1-p^r or (1-p)
    else if((code-low)>=bound1) return 1; // >= (1-p)^r or (1-p)
    else                        return 2;
}
void extend(int &nNodes, int &nPaths, byte y, bool b){
    int nKids = nPaths;
    for(int k=0; k<nPaths; k++){// for each active path
        byte x = get_symbol(paths[k]->low, paths[k]->high, paths[k]->code, b);
        if(x==2){// fork node
            paths[nKids++] = create_kid(paths[k], nNodes, !y, y, b);
            paths[k] = create_kid(paths[k], nNodes, y, y, b);
        }else{// 0/1 node
            paths[k] = create_kid(paths[k], nNodes, x, y, b);
        }
    }
    nPaths = nKids;
}
int compare(const void *a, const void *b){
    return ((*(NODE**)b)->metric) - ((*(NODE**)a)->metric);
}
void traceback(byte *xr, NODE *leaf, int n){
    NODE *now = leaf;
    for(int i=(n-1); i>=0; i--){
        xr[i] = (now==(now->parent->kids[1]));
        now = (now->parent);
    }
}
int expand(byte *xr, byte *y, int M, int n, int t=0){
    int nNodes=0, nPaths=0;
    paths[nPaths++] = create_root(nNodes);
    for(int i=0; i<n; i++){
        extend(nNodes, nPaths, y[i], i<(n-t));
        if((i<(n-t-1)) && (nPaths>M)){
            qsort(paths, nPaths, sizeof(NODE*), compare); // sort paths in the descending order of metric
            nPaths = min(nPaths,M);
        }
    }
    for(int j=1; j<nPaths; j++){
        if((paths[j]->metric) > (paths[0]->metric)){
            paths[0] = paths[j];
        }
    }
    traceback(xr, paths[0], n);
    return nNodes;
}
////////////////////////////////////////////////////////////////////////////////////////////////
int main(int argc, char *argv[]){
    int n=(1<<8), t=18, M=(1<<10);  // M is the number of surviving paths after pruning
    double p=0.5, q=0.07;           // p is the bias probability of X; q is the crossover probability between X and Y
    double R=0.5, r=(n*R-t)/(n-t);  // R is the average rate; r is the rate for body symbol
    int FRM=(1<<16), EFRM=(1<<8);   // FRM is the maximum number of frames; EFRM is the maximum number of erroneous frames
    
    setsteps(p,r);
    byte *x = new byte[3*n], *y = x+n, *xr = y+n;
    new_codec(n,M);
    clock_t start = clock();
    for(int l=0,k=0; l<FRM; l++){
        for(int i=0; i<n; i++){
            x[i] = (rand()<RAND_MAX*p);
            y[i] = x[i]^(rand()<RAND_MAX*q);
        }
        compress(x,n,t);
        expand(xr,y,M,n,t);
        k += (memcmp(x,xr,n)!=0);
        if((k==EFRM)||((l+1)==FRM)){
            printf("FER: %f\n", k/double(l+1));
            break;
        }
    }
    clock_t finish = clock();
    double duration = (double)(finish-start)/CLOCKS_PER_SEC;
    printf("%.0f ms\n", duration*1e3);
    free_codec();
    delete[] x;
    return 0;
}
