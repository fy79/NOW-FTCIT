//
//  main.cpp
//  dac_ccs
//
//  Created by 勇 方 on 7/29/16.
//  Copyright © 2016 Yong. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <memory.h>
#include <float.h>
#include <iostream>
using namespace std;

typedef unsigned char byte;

// binary entropy function
#define H(p)	(((p)*(1-(p))==0.0) ? (0.0) : ((-(p)*log2(p)-(1-(p))*log2(1-(p)))))

// parameters to control the AC codec
const int WIDTH = 32;
const unsigned HRNG = (1<<(WIDTH-1));    // half of the range
const unsigned QRNG = (1<<(WIDTH-2));    // quarter of the range
const unsigned MASK = (HRNG|(HRNG-1));

// local variables used in this file
double top0[2], bot1[2];
void set_intervals(double p, double r){
    top0[0] = (1-p);            // upper bound of 0 for tail
    top0[1] = pow(1-p,r);		// upper bound of 0 for body
    bot1[0] = (1-p);            // lower bound of 1 for tail
    bot1[1] = (1-pow(p,r));	// lower bound of 1 for body
}

// encode one source symbol
void encode_symbol(byte *str, unsigned &low, unsigned &high, int &nuf, int &ptr, byte s, bool isb){
    if(s)	low += unsigned((high-low)*bot1[isb] + bot1[isb]+0.5);
    else	high = low + unsigned((high-low)*top0[isb] + top0[isb]-0.5);
    while(!((high^low)&HRNG)){
        str[ptr++] = (low>=HRNG);
        while(nuf){
            str[ptr++] = (low<HRNG);
            nuf--;
        }
        low <<= 1; high <<= 1; high |= 1;
    }
    while((high&QRNG)<(low&QRNG)){
        nuf++;
        low  -= QRNG; low  <<= 1;
        high -= QRNG; high <<= 1; high |= 1;
    }
}

int compress(byte *str, byte *src, int n, int t){
    unsigned low = 0, high = MASK;
    int nuf = 0, ptr = 0;
    for(int i=0; i<n; i++){
        encode_symbol(str, low, high, nuf, ptr, src[i], (i<(n-t)));
    }
    str[ptr] = 1;   // this bit is VERY important for the final CCS
    return ptr;
}

// remove one source symbol
void remove_symbol(byte *str, unsigned &low, unsigned &high, unsigned &code, int &ptr, byte s, bool isb){
    if(s)	low += unsigned((high-low)*bot1[isb] + bot1[isb]+0.5);
    else	high = low + unsigned((high-low)*top0[isb] + top0[isb]-0.5);
    while(!((high^low)&HRNG)){
        low  <<= 1;
        high <<= 1; high |= 1;
        code <<= 1; code |= str[ptr++];
    }
    while((high&QRNG)<(low&QRNG)){
        low  -= QRNG; low  <<= 1;
        high -= QRNG; high <<= 1; high |= 1;
        code -= QRNG; code <<= 1; code |= str[ptr++];
    }
}

unsigned expand(byte *str, byte *src, int n, int t, double **ccs, int ncells){
    unsigned low = 0, high = MASK, code = 0;
    int ptr = 0;
    for(int i=0; i<WIDTH; i++){
        code <<= 1;
        code |= str[ptr++];
    }
    for(int i=0; i<n; i++){
        double u = (code-low)/(high-low+1.0);
        ccs[i][int(u*ncells)]++;
        remove_symbol(str, low, high, code, ptr, src[i], (i<(n-t)));
    }
    double u = (code-low)/(high-low+1.0);   // final CCS
    ccs[n][int(u*ncells)]++;
    return 0;
}

void print_settings(int n, int t, double r, double p, int ncells, int ntries){
    double R = (r*(n-t)+t)*H(p)/n;  // code rate
    cout<<"************************Settings**********************\n";
    cout<<"p = "<<p<<endl<<"H(p) = "<<H(p)<<endl<<"R = "<<R<<endl;
    cout<<"n = "<<n<<endl<<"t = "<<t<<endl<<"r = "<<r<<endl;
    cout<<"Number of Cells: "<<ncells<<endl;
    cout<<"Number of Tries: "<<ntries<<endl;
    cout<<"********************End of Settings*******************\n\n";
}

// n t r p ncells ntries file_name seed
int main(int argc, const char * argv[]) {
    // load and print settings
    int n = atoi(argv[1]);      // code length
    int t = atoi(argv[2]);      // tail length
    double r = atof(argv[3]);   // overlap factor for body
    double p = atof(argv[4]);   // bias probability of source
    set_intervals(p, r);
    int ncells = atoi(argv[5]); // number of cells
    int ntries = atoi(argv[6]); // number of tries
    print_settings(n, t, r, p, ncells, ntries);
    int seed = atoi(argv[7]);      // initial seed
    srand(seed); // srand((unsigned)_rdtsc());
    
    // allocate memory
    double *allccs = new double[(n+1)*ncells];
    memset(allccs, 0, sizeof(double)*(n+1)*ncells);
    double **ccs = new double*[n+1];
    for(int i=0; i<=n; i++){
        ccs[i] = allccs + i*ncells;
    }
    byte *src = new byte[5*n], *str = src+n;
    
    // codec
    for(int k=0; k<ntries; k++){
        for(int i=0; i<n; i++){// generate source block
            src[i] = (rand()<RAND_MAX*p);
        }
        memset(str, 0, 4*n);    // clear bitstream
        compress(str, src, n, t);
        expand(str, src, n, t, ccs, ncells);
    }
    
    // output CCS
    FILE *fp = fopen(argv[8], "wt");    // ccs file
    if(!fp){
        cout<<"File open fails!\n";
        return 1;
    }
    for(int i=0; i<=n; i++){
        for(int j=0; j<ncells; j++){
            ccs[i][j] = (ccs[i][j]*ncells)/ntries;
            fprintf(fp, "%f\n", ccs[i][j]);
        }
    }
    fclose(fp);
    
    delete[] src;
    delete[] allccs;
    return 0;
}
