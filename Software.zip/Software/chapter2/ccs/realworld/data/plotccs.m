n = 256;
ncells = 256;
fp = fopen('256_0_.5_.5_256.txt', 'r');
ccs = fscanf(fp, '%f', [ncells, n+1]);
u = (0:(ncells-1))/ncells;
plot(u, ccs(:,256));