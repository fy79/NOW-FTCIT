function ccs = get_ccs_round(p,r,n,m)
ccs = ones(n,m);
p0 = 1-p; p1 = p;       % p0,p1: probability distribution of the source
q0 = (1-p)^r; q1 = p^r; % q0,q1: lengths of enlarged intervals
ccs0 = zeros(1,m);
ccs1 = zeros(1,m);
for i=2:n
    for j=0:(m-1)
        j0 = round(j/q0);        
        if j0>=0 && j0<m
            ccs0(j+1) = ccs(i-1,j0+1);
        else
            ccs0(j+1) = 0;
        end 
        
        j1 = round((j-m*(1-q1))/q1);
        if j1>=0 && j1<m
            ccs1(j+1) = ccs(i-1,j1+1);
        else 
            ccs1(j+1) = 0;
        end       
    end
    ccs(i,:) = ((p0/q0)*ccs0 + (p1/q1)*ccs1);
    ccs(i,:) = ccs(i,:) * (m/sum(ccs(i,:)));
end