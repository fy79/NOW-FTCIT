function ccs = get_ccs_linear(p,r,n,m)
ccs = ones(n,m);
p0 = 1-p; p1 = p;       % p0,p1: probability distribution of the source
q0 = (1-p)^r; q1 = p^r; % q0,q1: lengths of enlarged intervals
ccs0 = zeros(1,m);
ccs1 = zeros(1,m);
for i=2:n
    for j=0:(m-1)
        j0 = j/q0; l0 = floor(j0); h0 = ceil(j0);
        if l0>(m-1)
            temp0 = 0;
        elseif h0>(m-1) || l0==h0
            temp0 = ccs(i-1,l0+1);
        else 
            temp0 = (h0-j0)*ccs(i-1,l0+1) + (j0-l0)*ccs(i-1,h0+1);
        end 
        ccs0(j+1) = temp0;
            
        j1 = (j-m*(1-q1))/q1; l1 = floor(j1); h1 = ceil(j1);
        if h1<0
            temp1 = 0;
        elseif l1<0 || l1==h1
            temp1 = ccs(i-1,h1+1);
        else 
            temp1 = (h1-j1)*ccs(i-1,l1+1) + (j1-l1)*ccs(i-1,h1+1);
        end       
        ccs1(j+1) = temp1;
    end
    ccs(i,:) = (p0/q0)*ccs0 + (p1/q1)*ccs1;
    ccs(i,:) = ccs(i,:) * (m/sum(ccs(i,:)));
end