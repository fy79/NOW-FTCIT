%% this file generates Figure 2.7 in the monograph and also saves CCS into the ccs.txt file.

p = 0.5;
r = 0.5;
n = 65; 
m = 2^16;

ccslin = get_ccs_linear(p,r,n,m);
ccsrnd = get_ccs_round(p,r,n,m);
ccsfine = get_ccs_fine(p,r,n,m);

save('ccs.txt', 'p', 'r', 'n', 'm', 'ccsfine', '-ascii');

u = (0:(m-1))/m;

%%
figure(1);
plot(u,ccsfine(1,:)); hold on;
plot(u,ccsfine(2,:)); 
plot(u,ccsfine(3,:)); 
plot(u,ccsfine(9,:));
grid on; axis tight;
set(gca, 'FontSize', 16);
title({'$r=0.5$, $N=2^{16}$, Fine'}, 'interpreter', 'latex');
xlabel({'$u$'}, 'interpreter', 'latex');
ylabel({'Numerical $f_{i,n}(u)$'}, 'interpreter', 'latex');
legend({'$(n-i)=0$','$(n-i)=1$','$(n-i)=2$','$(n-i)=8$'}, 'interpreter', 'latex');

%%
figure(2);
plot(u,ccsfine(17,:)); hold on;
plot(u,ccsfine(33,:)); 
plot(u,ccsfine(65,:));
grid on;
axis tight;
set(gca, 'FontSize', 16);
title({'$r=0.5$, $N=2^{16}$, Fine'}, 'interpreter', 'latex');
xlabel({'$u$'}, 'interpreter', 'latex');
ylabel({'Numerical $f_{i,n}(u)$'}, 'interpreter', 'latex');
legend({'$(n-i)=16$','$(n-i)=32$','$(n-i)=64$'}, 'interpreter', 'latex');
% create smaller axes in top right, and plot on it
axes('Position',[.368 .2 .3 .3]); box on;
x2 = ((m/2-m/128):(m/2+m/128-1))/m;
y2a = ccsfine(17,(m/2-m/128+1):(m/2+m/128));
y2b = ccsfine(33,(m/2-m/128+1):(m/2+m/128));
y2c = ccsfine(65,(m/2-m/128+1):(m/2+m/128));
plot(x2,y2a); hold on;
plot(x2,y2b);
plot(x2,y2c);
grid on; axis tight;

%%
figure(3);
plot(u,ccslin(1,:)); hold on;
plot(u,ccslin(2,:)); 
plot(u,ccslin(3,:)); 
plot(u,ccslin(9,:));
grid on; axis tight;
set(gca, 'FontSize', 16);
title({'$r=0.5$, $N=2^{16}$, Linear'}, 'interpreter', 'latex');
xlabel({'$u$'}, 'interpreter', 'latex');
ylabel({'Numerical $f_{i,n}(u)$'}, 'interpreter', 'latex');
legend({'$(n-i)=0$','$(n-i)=1$','$(n-i)=2$','$(n-i)=8$'}, 'interpreter', 'latex');

%%
figure(4);
plot(u,ccslin(17,:)); hold on;
plot(u,ccslin(33,:)); 
plot(u,ccslin(65,:));
grid on; axis tight;
set(gca, 'FontSize', 16);
title({'$r=0.5$, $N=2^{16}$, Linear'}, 'interpreter', 'latex');
xlabel({'$u$'}, 'interpreter', 'latex');
ylabel({'Numerical $f_{i,n}(u)$'}, 'interpreter', 'latex');
legend({'$(n-i)=16$','$(n-i)=32$','$(n-i)=64$'}, 'interpreter', 'latex');
% create smaller axes in top right, and plot on it
axes('Position',[.368 .2 .3 .3]); box on;
x2 = ((m/2-m/128):(m/2+m/128-1))/m;
y2a = ccslin(17,(m/2-m/128+1):(m/2+m/128));
y2b = ccslin(33,(m/2-m/128+1):(m/2+m/128));
y2c = ccslin(65,(m/2-m/128+1):(m/2+m/128));
plot(x2,y2a); hold on;
plot(x2,y2b);
plot(x2,y2c);
grid on; axis tight;

%%
figure(5);
plot(u,ccsrnd(1,:)); hold on;
plot(u,ccsrnd(2,:)); 
plot(u,ccsrnd(3,:)); 
plot(u,ccsrnd(9,:));
grid on; axis tight;
set(gca, 'FontSize', 16);
title({'$r=0.5$, $N=2^{16}$, Rounding'}, 'interpreter', 'latex');
xlabel({'$u$'}, 'interpreter', 'latex');
ylabel({'Numerical $f_{i,n}(u)$'}, 'interpreter', 'latex');
legend({'$(n-i)=0$','$(n-i)=1$','$(n-i)=2$','$(n-i)=8$'}, 'interpreter', 'latex');

%%
figure(6);
plot(u,ccsrnd(17,:)); hold on;
plot(u,ccsrnd(33,:)); 
plot(u,ccsrnd(65,:));
grid on; axis tight;
set(gca, 'FontSize', 16);
title({'$r=0.5$, $N=2^{16}$, Rounding'}, 'interpreter', 'latex');
xlabel({'$u$'}, 'interpreter', 'latex');
ylabel({'Numerical $f_{i,n}(u)$'}, 'interpreter', 'latex');
legend({'$(n-i)=16$','$(n-i)=32$','$(n-i)=64$'}, 'interpreter', 'latex');
% create smaller axes in top right, and plot on it
axes('Position',[.368 .2 .3 .3]); box on;
x2 = ((m/2-m/128):(m/2+m/128-1))/m;
y2a = ccsrnd(17,(m/2-m/128+1):(m/2+m/128));
y2b = ccsrnd(33,(m/2-m/128+1):(m/2+m/128));
y2c = ccsrnd(65,(m/2-m/128+1):(m/2+m/128));
plot(x2,y2a); hold on;
plot(x2,y2b);
plot(x2,y2c);
grid on; axis tight;