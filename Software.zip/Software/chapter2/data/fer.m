%% This file generates Figure 2.8 in the monograph.

%% epsilon = 0.01
figure(1);
woutccs = [0.813344, 0.595349, 0.078419, 0.035280, 0.031996, 0.031551];
withccs = [0.813990, 0.433715, 0.063793, 0.033762, 0.031846, 0.031922];
semilogy(0:5, woutccs, '-+'); hold on;
semilogy(0:5, withccs, '-x');
grid on; axis tight;
set(gca, 'FontSize', 16);
title({'$n=2^8$, $\epsilon=0.01$'}, 'interpreter', 'latex');
xlabel({'$\log_2{M}$'}, 'interpreter', 'latex');
ylabel({'Frame-Error-Rate'}, 'interpreter', 'latex');
legend({'w/o CCS','with CCS'}, 'interpreter', 'latex');

%% epsilon = 0.02
figure(2);
woutccs = [0.965127, 0.821171, 0.217919, 0.090579, 0.073967, 0.068651, 0.068239];
withccs = [0.963311, 0.691892, 0.177562, 0.085000, 0.070262, 0.067368, 0.068785];
semilogy(0:6, woutccs, '-+'); hold on;
semilogy(0:6, withccs, '-x');
grid on; axis tight;
set(gca, 'FontSize', 16);
title({'$n=2^8$, $\epsilon=0.02$'}, 'interpreter', 'latex');
xlabel({'$\log_2{M}$'}, 'interpreter', 'latex');
ylabel({'Frame-Error-Rate'}, 'interpreter', 'latex');
legend({'w/o CCS','with CCS'}, 'interpreter', 'latex');

%% epsilon = 0.03
figure(3);
woutccs = [0.990329, 0.923354, 0.396285, 0.176887, 0.128112, 0.109966, 0.105036, 0.106467];
withccs = [0.991288, 0.842105, 0.338961, 0.163083, 0.122826, 0.109308, 0.109648, 0.106511];
semilogy(0:7, woutccs, '-+'); hold on;
semilogy(0:7, withccs, '-x');
grid on; axis tight;
set(gca, 'FontSize', 16);
title({'$n=2^8$, $\epsilon=0.03$'}, 'interpreter', 'latex');
xlabel({'$\log_2{M}$'}, 'interpreter', 'latex');
ylabel({'Frame-Error-Rate'}, 'interpreter', 'latex');
legend({'w/o CCS','with CCS'}, 'interpreter', 'latex');

%% epsilon = 0.04
figure(4);
woutccs = [0.999024, 0.974310, 0.558038, 0.296812, 0.199727, 0.164419, 0.155199, 0.152449, 0.149511];
withccs = [1.000000, 0.928377, 0.497812, 0.271474, 0.192844, 0.162334, 0.151323, 0.154683, 0.150832];
semilogy(0:8, woutccs, '-+'); hold on;
semilogy(0:8, withccs, '-x');
grid on; axis tight;
set(gca, 'FontSize', 16);
title({'$n=2^8$, $\epsilon=0.04$'}, 'interpreter', 'latex');
xlabel({'$\log_2{M}$'}, 'interpreter', 'latex');
ylabel({'Frame-Error-Rate'}, 'interpreter', 'latex');
legend({'w/o CCS','with CCS'}, 'interpreter', 'latex');


