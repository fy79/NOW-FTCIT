#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <memory.h>
#include <math.h>
#include <float.h>
#include <iostream>
using namespace std;
typedef unsigned char byte;

////////////////////////////////////////////////////////////////////////////////////////////////
const int WIDTH = 32;
const unsigned HRNG = (1U<<(WIDTH-1));  // half of the range
const unsigned QRNG = (1U<<(WIDTH-2));  // quarter of the range
const unsigned MASK = HRNG|(HRNG-1);
const int SCALE = (1<<10);
////////////////////////////////////////////////////////////////////////////////////////////////
struct NODE{
    unsigned low, high, code; 
    int ptr, exmetric, metric;
    NODE *parent, *kids[2];
};
static NODE **paths=NULL;
static NODE *nodes=NULL;
static byte *str=NULL;/* This is the i/o buffer    */
static double steps[3];
int lgp[2], lgq[2];
void new_codec(int n, int M, float p, float q, float r){
    str = new byte[n];
    paths = new NODE*[(M<<1)+1];
    nodes = new NODE[(M<<1)*n+1];
    //
    steps[0] = 1-p;
    steps[1] = powf(1-p,r); // (1-p)^r => [0, steps[1])
    steps[2] = 1-powf(p,r); // 1-p^r => [steps[2], 1)
    // [0, steps[2], steps[0], steps[1], 1)
    lgp[0] = int(log(1-p)*SCALE);
    lgp[1] = int(log(p)*SCALE);
    lgq[0] = int(log(1-q)*SCALE);
    lgq[1] = int(log(q)*SCALE);
}
void free_codec(void){
    delete[] str;
    delete[] nodes;
    delete[] paths;
}
////////////////////////////////////////////////////////////////////////////////////////////////
static void encode_symbol(unsigned &low, unsigned &high, int &ptr, int &underflow, byte x, bool b=true){
    int a = b+(b&x);
    unsigned length = unsigned((high-low)*steps[a]+steps[a]+0.5);// the only float-point operation
    if(x) low += length;            // update the lower bound of "1"
    else  high = low + length - 1;  // update the upper bound of "0"
    while(!((high^low)&HRNG)){
        str[ptr++] = (low>=HRNG);
        while(underflow){
            str[ptr++] = (low<HRNG);
            underflow--;
        }
        low <<= 1; high <<= 1; high |= 1;
    }
    while((high&QRNG)<(low&QRNG)){
        underflow++;
        low  -= QRNG; low  <<= 1;
        high -= QRNG; high <<= 1; high |= 1;
    }
}
int compress(byte *x, int n, int t=0){
    int ptr=0, underflow=0;
    unsigned low=0, high=MASK;
    memset(str, 0, n*sizeof(byte));
    for(int i=0; i<n; i++){
        encode_symbol(low, high, ptr, underflow, x[i], i<(n-t));
    }
    str[ptr] = 1;
    return ptr;
}
////////////////////////////////////////////////////////////////////////////////////////////////
byte get_symbol(unsigned low, unsigned high, unsigned code, bool b=true){
    unsigned bound0 = unsigned((high-low)*steps[b<<1]+steps[b<<1]+0.5);
    unsigned bound1 = unsigned((high-low)*steps[b]+steps[b]+0.5);
    if((code-low)<bound0)       return 0; // < 1-p^r or (1-p)
    else if((code-low)>=bound1) return 1; // >= (1-p)^r or (1-p)
    else                        return 2;
}
static void remove_symbol(unsigned &low, unsigned &high, unsigned &code, int &ptr, byte x, bool b=true){
    int a = b+(b&x);
    unsigned length = unsigned((high-low)*steps[a]+steps[a]+0.5);// the only float-point operation
    if(x) low += length;            // update the lower bound of "1"
    else  high = low + length - 1;  // update the upper bound of "0"
    while(!((high^low)&HRNG)){
        low  <<= 1;
        high <<= 1; high |= 1;
        code <<= 1; code |= str[ptr++];
    }
    while((high&QRNG)<(low&QRNG)){
        low  -= QRNG; low  <<= 1;
        high -= QRNG; high <<= 1; high |= 1;
        code -= QRNG; code <<= 1; code |= str[ptr++];
    }
}
static NODE *create_root(int &nNodes){
    NODE *root = nodes+(nNodes++);
    root->low = 0; root->high = MASK; root->code = 0; root->ptr = 0;
    for(int i=0; i<WIDTH; i++){
        root->code <<= 1;
        root->code |= str[(root->ptr)++];
    }
    root->exmetric = 0;
    root->parent = NULL; root->kids[0] = NULL; root->kids[1] = NULL;
    return root;
}
static NODE *create_kid(NODE *parent, int &nNodes, byte x, int yinf, const int *ccs, int nseg, float r, bool b=true){
    NODE *kid = nodes+(nNodes++);
    kid->exmetric = parent->exmetric + yinf;// + b*(1-r)*lgp[x]; // update extrinsic metric
    memcpy(kid, parent, 3*sizeof(unsigned)+sizeof(int));// (low, high, code, ptr)
    remove_symbol(kid->low, kid->high, kid->code, kid->ptr, x, b);
    double u = ((kid->code)-(kid->low))/((kid->high)-(kid->low)+1.0);
    kid->metric = kid->exmetric + (ccs?ccs[int(u*nseg)]:0); // overall metric
    kid->parent = parent; kid->kids[0] = NULL; kid->kids[1] = NULL;
    parent->kids[x] = kid;
    return kid;
}
static void extend(int &nNodes, int &nPaths, byte y, const int *ccs, int nseg, float r, bool body=true){
    int nKids = nPaths;
    for(int k=0; k<nPaths; k++){// for each active path
        byte x = get_symbol(paths[k]->low, paths[k]->high, paths[k]->code, body);
        if(x==2){// fork node
            paths[nKids++] = create_kid(paths[k], nNodes, !y, lgq[1], ccs, nseg, r, body);
            paths[k] = create_kid(paths[k], nNodes, y, lgq[0], ccs, nseg, r, body);
        }else{// 0/1 node
            paths[k] = create_kid(paths[k], nNodes, x, lgq[x^y], ccs, nseg, r, body);
        }
    }
    nPaths = nKids;
}
static int compare(const void *a, const void *b){
    // this is a shortcut of comparison, good enough but may be slightly worse than its correct form.
    return ((*(NODE**)b)->metric)-((*(NODE**)a)->metric);

    // this is the correct comparison.
//    return (((*(NODE**)b)->metric)>((*(NODE**)a)->metric))-(((*(NODE**)b)->metric)<((*(NODE**)a)->metric));
}
static void traceback(byte *xr, NODE *leaf, int n){
    NODE *now = leaf;
    for(int i=(n-1); i>=0; i--){
        xr[i] = (now==(now->parent->kids[1]));
        now = (now->parent);
    }
}
int expand(byte *xr, const byte *y, int **ccs, int nccs, int nseg, int M, int n, float r, int t=0){
    int nNodes=0, nPaths=0;
    paths[nPaths++] = create_root(nNodes);
    for(int i=0; i<n; i++){
        extend(nNodes, nPaths, y[i], ccs?ccs[min((n-i),nccs)-1]:NULL, nseg, r);
        qsort(paths, nPaths, sizeof(NODE*), compare); // sort paths in the descending order of metric
        nPaths = min(nPaths,M);
    }
    traceback(xr, paths[0], n);
    return nNodes;
}
////////////////////////////////////////////////////////////////////////////////////////////////
int main(int argc, char *argv[]){
    int n=(1<<8), M=(1<<3);
    float p=0.5, r=0.5, q=0.04;

    float **ccstmp=NULL;
    int **ccs=NULL, nccs=0, nseg=0;
    FILE *fccs = fopen("ccs.txt", "rt");
    if(fccs){
        float ptmp, rtmp;
        fscanf(fccs, "%f", &ptmp);
        fscanf(fccs, "%f", &rtmp);
        if((p==ptmp)&&(r==rtmp)){
            fscanf(fccs, "%f", &ptmp);
            fscanf(fccs, "%f", &rtmp);
            nccs = int(ptmp);
            nseg = int(rtmp);
            ccstmp = new float*[nccs];
            ccs = (int**)ccstmp;
            for(int i=0; i<nccs; i++){
                ccstmp[i] = new float[nseg];
                ccs[i] = (int*)ccstmp[i];
                for(int j=0; j<nseg; j++){
                    fscanf(fccs, "%f", &ccstmp[i][j]);
                    ccs[i][j] = int(log(ccstmp[i][j])*SCALE);
                }
            }
        }
        fclose(fccs);
    }
    
    byte *x=new byte[3*n], *y=x+n, *xr=y+n;
    new_codec(n,M,p,q,r);

    // loop for trials
    srand(0);
    int nerrs=0, ntries=0;
    while((nerrs<(1<<10)) && (ntries<(1<<20))){
        for(int i=0; i<n; i++){
            x[i] = (rand()<(RAND_MAX*p));
            y[i] = x[i]^(rand()<(RAND_MAX*q));
        }
        compress(x,n);
        expand(xr,y,ccs,nccs,nseg,M,n,r);
        nerrs += (memcmp(x,xr,n)!=0);
        ntries++;
    }
    printf("FER: %f\n", nerrs/double(ntries));
    
    free_codec();
    delete[] x;
    if(ccs){
        for(int i=0; i<nccs; i++){
            delete[] ccs[i];
        }
        delete[] ccs;
    }
    return 0;
}
