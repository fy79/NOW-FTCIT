r = 0.5;
e = 0.01:0.01:0.1;

figure(1);
fer1 = [0.005867, 0.011513, 0.017657, 0.022676, 0.028859, 0.034624, 0.040742, 0.046514, 0.052270, 0.058749];
plot(e, fer1, '-+'); hold on;
plot(e, (2-2^r)*e, '-x');
grid on; axis tight;
set(gca, 'FontSize', 16);
title({'$n=2^8$ and $r=0.5$, given $X^{n-1}$'}, 'interpreter', 'latex');
xlabel({'$\epsilon$'}, 'interpreter', 'latex');
ylabel({'Frame-Error-Rate'}, 'interpreter', 'latex');
legend({'Experiment','Theory'}, 'interpreter', 'latex', 'location', 'northwest');

figure(2);
fer2 = [0.012385, 0.025051, 0.035478, 0.047434, 0.059740, 0.069812, 0.081406, 0.094561, 0.105993, 0.116070];
plot(e, fer2, '-+'); hold on;
plot(e, (5-2^(2*r+1)+2^r)/2*e - (1-2^(2*r)+2^r)*(e.*e), '-x');
grid on; axis tight;
set(gca, 'FontSize', 16);
title({'$n=2^8$ and $r=0.5$, given $X^{n-2}$'}, 'interpreter', 'latex');
xlabel({'$\epsilon$'}, 'interpreter', 'latex');
ylabel({'Frame-Error-Rate'}, 'interpreter', 'latex');
legend({'Experiment','Theory'}, 'interpreter', 'latex', 'location', 'northwest');


r = 0.25;
e = 0.01:0.005:0.04;

figure(3);
fer1 = [0.007973, 0.012154, 0.015972, 0.019933, 0.024444, 0.028399, 0.032531];
plot(e, fer1, '-+'); hold on;
plot(e, (2-2^r)*e, '-x');
grid on; axis tight;
set(gca, 'FontSize', 16);
title({'$n=2^8$ and $r=0.25$, given $X^{n-1}$'}, 'interpreter', 'latex');
xlabel({'$\epsilon$'}, 'interpreter', 'latex');
ylabel({'Frame-Error-Rate'}, 'interpreter', 'latex');
legend({'Experiment','Theory'}, 'interpreter', 'latex', 'location', 'northwest');

figure(4);
fer2 = [0.017118, 0.025224, 0.033621, 0.041608, 0.050068, 0.058358, 0.066285];
plot(e, fer2, '-+'); hold on;
plot(e, (5-2^(2*r+1)+2^r)/2*e - (1-2^(2*r)+2^r)*(e.*e), '-x');
grid on; axis tight;
set(gca, 'FontSize', 16);
title({'$n=2^8$ and $r=0.25$, given $X^{n-2}$'}, 'interpreter', 'latex');
xlabel({'$\epsilon$'}, 'interpreter', 'latex');
ylabel({'Frame-Error-Rate'}, 'interpreter', 'latex');
legend({'Experiment','Theory'}, 'interpreter', 'latex', 'location', 'northwest');
